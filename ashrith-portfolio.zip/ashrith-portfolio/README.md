# Ashrith Puppala — Portfolio

A single-page, dark, 3D-animated portfolio site. No build step — it's one static `index.html` with a Three.js hero (sensor-network wireframe), glassmorphism cards, and a draggable "glass slider" for the hackathon record.

## Deploy to Vercel

**Option A — Vercel CLI (fastest)**
```bash
npm i -g vercel
cd ashrith-portfolio
vercel --prod
```
When prompted, accept the defaults — Vercel auto-detects this as a static site (no framework, no build command needed).

**Option B — GitHub + Vercel dashboard**
1. Push this folder to a new GitHub repo.
2. Go to vercel.com → **Add New Project** → import the repo.
3. Framework Preset: **Other**. Leave Build Command and Output Directory blank.
4. Click **Deploy**.

## Before you deploy — fill these in
Open `index.html` and search for:
- `href="#"` on the **LinkedIn** and **Instagram** footer links — swap in your real profile URLs.
- `href="#"` on **Download Résumé (PDF)** — point it at your hosted résumé, or drop a `resume.pdf` in this folder and link to `resume.pdf`.
- `mailto:hello@ashrithpuppala.com` — swap in your real email.

## Local preview
Just open `index.html` in a browser, or serve it:
```bash
npx serve .
```

## Structure
- `index.html` — everything: markup, styles, and scripts in one file.
- `vercel.json` — minimal static-hosting config (clean URLs).

## Notes
- Three.js is loaded from a CDN (cdnjs) at runtime — no npm install needed.
- Respects `prefers-reduced-motion` (animation is disabled for users who request it).
- Fully responsive down to mobile; nav collapses, grids stack to a single column.
